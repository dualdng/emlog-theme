<?php
include('../../../include/comment_controller.php');
$com=new Comment_Controller; 
$res=$com->addComment();
?>
