<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div><!--end #content-->
</div><!--end #wrap-->
<div style="clear:both;"></div>
<div id="footerbar">
COPRIGHT ◎ 2010-2013 /
	POWERED BY <a href="http://www.emlog.net" title="采用emlog系统">EMLOG</a> / THEMED BY <a href='http://www.siyochen.com'>SIYOCHEN</a>
<p>DON'T FORGET TRANSPLANT BY <a href='http://www.uuuuj.com'>BRAGUE!</a></p>
	<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo $icp; ?></a> <?php echo $footer_info; ?>
	<?php doAction('index_footer'); ?>
</div><!--end #footerbar-->
<script>prettyPrint();</script>
</body>
</html>
