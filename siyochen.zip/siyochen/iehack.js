$(document).ready(function(){
		$('.sideshow').css({'display':'none'})
})
